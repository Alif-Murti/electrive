<?php
$host="localhost"; //host server
$user="root"; //user login
$pass =""; //password
$db = "skripsi"; //nama db
$conn = mysqli_connect($host, $user, $pass, $db) or die ("Koneksi gagal");
?>